OneWire implementation for MSP430
=================================
- implemented for MSP430 and tested on TI LaunchPad but can be easily
  altered for any MCU

Prerequisities
--------------
- msp430-gcc
- scons (http://www.scons.org/)
